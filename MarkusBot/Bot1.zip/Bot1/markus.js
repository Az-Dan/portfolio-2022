const { Client, Intents, GuildStickerManager } = require("discord.js")
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_PRESENCES, Intents.FLAGS.GUILD_MESSAGE_REACTIONS] });
const prefix = 'm!';
const tokenfromjson = require("./config.json");
const TOKEN = tokenfromjson.token;
const fs = require('fs');
var suggestionBox;

client.once("ready", () => {
    suggestionBox = client.channels.cache.get('729362025183969301');
    console.log(`Logged in as ${client.user.tag}!`);
})

client.on('messageCreate', async message => {
    if (message.content === prefix + 'ping') {
        await message.channel.send('Loading data').then (async (msg) =>{
            await msg.delete()
            await message.channel.send(`Pong! Latency is ${msg.createdTimestamp - message.createdTimestamp}ms. API Latency is ${Math.round(client.ws.ping)}ms.`);
        })
    }
    if (message.content == prefix + 'uptime') {
        let totalSeconds = (client.uptime / 1000);
        let days = Math.floor(totalSeconds / 86400);
        totalSeconds %= 86400;
        let hours = Math.floor(totalSeconds / 3600);
        totalSeconds %= 3600;
        let minutes = Math.floor(totalSeconds / 60);
        let seconds = Math.floor(totalSeconds % 60);
        let uptime = `${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds`;
        message.channel.send("Active for " + uptime);
    }
    if (message.content.startsWith(prefix + 'choose')) {
        if (message.author.bot) return;
        const choicedata = message.content.slice(9);
        if (message.content.includes("|")) {
            let choicearray = choicedata.split('|');
            let choice = Math.floor(Math.random() * (choicearray.length));
            message.channel.send("**" + choicearray[choice].trim() + "** was chosen!");
        }
        else {
            message.channel.send("Please separate each choice with a vertical bar (`|`).")
        }
    }
    if (message.content.startsWith(prefix + 'say')) {
        if (message.author.id !== "263814852638801920") return;
        const SayMessage = message.content.slice(6).trim();
        await message.channel.send(SayMessage)
    }
      if (message.content === prefix + "help") {
        if (message.author.bot) return;
        message.channel.send("`/help` for music bot commands. \n`m!help` - displays this message! \n`m!suggest` - puts a suggestion in the suggestion box. Please don't abuse this feature.\n`m!ping` - pings the bot.\n`m!uptime` - displays bot uptime.\n`m!choose` - makes a choice from options separated by **|**. \n`m!roll` - dicerolls! (WIP) AdX+C to have C added to each roll, and AdX + C to have C added at the very end.")
    }
    if (message.content.startsWith(prefix + 'suggest')) {
        const suggestion = message.content.slice(10).trim();
        suggestionBox.send(suggestion + "\n\n`Suggestion sent by " + message.author.username + "`").then(suggestmsg => {
            suggestmsg.react('<:chadyes:762180845036634113>');
            suggestmsg.react('<:Nothoughts:756947444536967238>');
            suggestmsg.react('<:JackDisgust:745456478823120906>');
        });
    }
    if (message.content.startsWith(prefix + 'roll')) {
        if (message.author.bot) return;
        const rolldata = message.content.slice(7).trim();
        let rollarray = rolldata.split(' ');
        for (let i = 0; i < rollarray.length; i++) {
            if (rollarray[i].charAt(0) == '+') {
                console.log("trailing addition found in roll");
                let addarray = rollarray[i].split('+');
                rollarray[i] = [];
                rollarray[i].push(addarray[addarray.length - 1]);
                console.log("trailing addition set to " + rollarray[i][0]);
            }
            else {
                if (rollarray[i].includes('d') == false) {
                    message.channel.send("Please format your roll as `adx`, where a is the number of dice to roll and x is the number of sides.");
                    return;
                }
                rollarray[i] = rollarray[i].split('d');
                if (rollarray[i][0] == "") {
                    rollarray[i][0] = "1";
                }
                if (rollarray[i][1].includes('+')) {
                    let addarray = rollarray[i][1].split('+');
                    rollarray[i].push(addarray[1]);
                }
            }
            console.assert(rollarray[i].length > 0 && rollarray[i].length < 4, "rollarray[" + i.toString() + "] does not have 1 - 3 elements");
            for (let j = 0; j < rollarray[i].length; j++) {
                rollarray[i][j] = parseInt(rollarray[i][j]);
            }
        }
        console.log(rollarray);
        let descstring = "Rolling ";
        let resstring = "";
        let resarray = [];
        let ressum = 0;
        for (let i = 0; i < rollarray.length; i++) {
            if (i != rollarray.length - 1 || rollarray[i].length != 1) {
                if (rollarray[i].length == 2) {
                    descstring += rollarray[i][0].toString() + " d" + rollarray[i][1].toString() + ", ";
                    for (let j = 0; j < rollarray[i][0]; j++) {
                        let res = Math.floor(Math.random() * (rollarray[i][1]) + 1);
                        resarray.push(res);
                        resstring += "**" + res.toString() + "** + ";
                        ressum += res;
                    }
                }
                else {
                    descstring += rollarray[i][0].toString() + " d" + rollarray[i][1].toString() + "+" + rollarray[i][2].toString() + ", ";
                    for (let j = 0; j < rollarray[i][0]; j++) {
                        let res = Math.floor(Math.random() * (rollarray[i][1]) + 1) + rollarray[i][2];
                        resarray.push(res);
                        resstring += "**" + res.toString() + "** + ";
                        ressum += res;
                    }
                }
            }
            else {
                descstring = descstring.slice(0, -2);
                descstring += " + " + rollarray[i][0].toString() + ", ";
                let res = rollarray[i][0];
                resarray.push(res);
                resstring += "**" + res.toString() + "** + ";
                ressum += res;
            }
        }
        descstring = descstring.slice(0, -2) + "..."
        resstring = resstring.slice(0, -3);
        resstring += " = `" + ressum.toString() + "`!";
        console.log(resstring);
        await message.channel.send(descstring + "\n" + resstring);
    }
})

client.login(TOKEN);
